<?php
	//receive the message from remote
	//put message to file
	
	if(!empty($_GET['message'])){
		$message=$_GET['message'];
		$name=$_GET['name'];
		$file=fopen("chat.txt","a");
		fwrite($file,$name);
		fwrite($file," : ");
		fwrite($file,$message);
		fwrite($file,"\n");
		fclose($file);
		
		echo "Message Sent";
	}
	

?>